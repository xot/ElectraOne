# README

This directory stores any preset dumps made by the remote script when `DUMP = True`.


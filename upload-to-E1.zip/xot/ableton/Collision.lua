info.setText("by www.xot.nl")

function defaultFormatter(valueObject, value)
    return("")
end

function formatFloat (valueObject, value)
  return (string.format("%.2f",value/100))
end

function formatLargeFloat (valueObject, value)
  return (string.format("%.1f",value/10))
end

function formatdB (valueObject, value)
  return (string.format("%.1f dB",value/10))
end

function formatFreq (valueObject, value)
  return (string.format("%.1f Hz",value/10))
end

function formatPan (valueObject, value)
  if value < 0 then
    return (string.format("%iL", -value))
  elseif value == 0 then
    return "C"
  else
    return (string.format("%iR", value))
  end
end

function formatPercent (valueObject, value)
  return (string.format("%.1f %%",value/10))
end

function formatIntPercent (valueObject, value)
  return (string.format("%.0f %%",value/10))
end

function formatDegree (valueObject, value)
  return (string.format("%i *",value))
end

function formatSemitone (valueObject, value)
  return (string.format("%i st",value))
end

function formatFineSemitone (valueObject, value)
  return (string.format("%.2f st",value/100))
end

function formatDetune (valueObject, value)
  return (string.format("%i ct",value))
end

-- start/stop display drawing

function aa()
  window.stop()
end

function zz()
  window.resume()
end

-- handling patch requests to switch between mixer/effect 

function patch.onRequest (device)
  print ("Patch Request pressed");
  if device.id == 1
    then midi.sendSysex(PORT_1, {0x00, 0x21, 0x45, 0x7E, 0x7E})
  end
end

rate1 = controls.get(19)
freq1 = controls.get(14)

rate2 = controls.get(33)
freq2 = controls.get(28)

function sync1(valueObject, value)
    freq1:setVisible(value == 0)
    rate1:setVisible(value ~= 0)
end

function sync2(valueObject, value)
    freq2:setVisible(value == 0)
    rate2:setVisible(value ~= 0)
end

material1 = controls.get(82)
inharmonics1 = controls.get(78)
radius1 = controls.get(93)
opening1 =  controls.get(87)


function type1(valueObject, value)
    material1:setVisible(value < 5)
    inharmonics1:setVisible(value < 5)
    radius1:setVisible(value > 4)
    opening1:setVisible(value > 4)
end

material2 = controls.get(113)
inharmonics2 = controls.get(109)
radius2 = controls.get(124)
opening2 =  controls.get(118)

function type2(valueObject, value)
    material2:setVisible(value < 5)
    inharmonics2:setVisible(value < 5)
    radius2:setVisible(value > 4)
    opening2:setVisible(value > 4)
end

info.setText("by www.xot.nl")

function defaultFormatter(valueObject, value)
    return("")
end

function formatFloat (valueObject, value)
  return (string.format("%.2f",value/100))
end

function formatLargeFloat (valueObject, value)
  return (string.format("%.1f",value/10))
end

function formatdB (valueObject, value)
  return (string.format("%.1f dB",value/10))
end

function formatFreq (valueObject, value)
  return (string.format("%.1f Hz",value/10))
end

function formatPan (valueObject, value)
  if value < 0 then
    return (string.format("%iL", -value))
  elseif value == 0 then
    return "C"
  else
    return (string.format("%iR", value))
  end
end

function formatPercent (valueObject, value)
  return (string.format("%.1f %%",value/10))
end

function formatIntPercent (valueObject, value)
  return (string.format("%.0f %%",value/10))
end

function formatDegree (valueObject, value)
  return (string.format("%i *",value))
end

function formatSemitone (valueObject, value)
  return (string.format("%i st",value))
end

function formatFineSemitone (valueObject, value)
  return (string.format("%.2f st",value/100))
end

function formatDetune (valueObject, value)
  return (string.format("%i ct",value))
end

-- start/stop display drawing

function aaa()
  window.stop()
end

function zzz()
  window.resume()
end

-- handling patch requests to switch between mixer/effect 

function patch.onRequest (device)
  print ("Patch Request pressed");
  if device.id == 1
    then midi.sendSysex(PORT_1, {0x00, 0x21, 0x45, 0x7E, 0x7E})
  end
end

-- handling forwarding mixer updates to second E1 (if attached)

function forward(f)
  cmdt = {0x00, 0x21, 0x45, 0x08, 0x0D}
  cmds = f .. "()"
  for i=1, string.len(cmds) do
    cmdt[i+5]= string.byte(cmds,i,i)
  end
  midi.sendSysex(PORT_1,cmdt)
end

function forward2(f,p1,p2)
  cmdt = {0x00, 0x21, 0x45, 0x08, 0x0D}
  cmds = f .. "(" .. p1 .. "," .. p2 .. ")"
  for i=1, string.len(cmds) do
    cmdt[i+5]= string.byte(cmds,i,i)
  end
  midi.sendSysex(PORT_1,cmdt)
end

function aa()
  forward('aa')
end

function zz()
  forward('zz')
end

function utl(idx,label)
  forward2('utl', tostring(idx), '"'..label..'"')
end

function ursl(idx,label)
  forward2('ursl', tostring(idx), '"'..label..'"')
end

function seqv(idx,flag)
  if flag then
    forward2('seqv',tostring(idx),'true')
  else
    forward2('seqv',tostring(idx),'false')
  end
end

function smv(tc,rc)
  forward2('smv', tostring(tc), tostring(rc))
end

mode = 0
delaysync = 0
lfosync = 0
spin = 0
wave = 0
delayison = false
envison = false

pcoarse = controls.get(1)
fcoarse = controls.get(3)
rcoarse = controls.get(5)

fcoarse:setSlot(1,1)
rcoarse:setSlot(1,1)

pwindow = controls.get(27)

pfine = controls.get(2)
mfine = controls.get(4)

mfine:setSlot(2,1)

lfoamounthz = controls.get(22)
lfoamountst = controls.get(25)

lfoamountst:setSlot(22,1)

lfofreq = controls.get(21)
lforate = controls.get(24)
lfooffset = controls.get(17)

lforate:setSlot(16,1)

lfophase = controls.get(14)
lfosetspin = controls.get(18)
lfospin = controls.get(19)

lfospin:setSlot(4,1)

lfowidth = controls.get(16)
lfoduty = controls.get(15)

lfowidth:setSlot(4,1)

envamounthz = controls.get(12)
envamountst = controls.get(11)
envattack = controls.get(8)
envrelease = controls.get(9)

envamountst:setSlot(23,1)

dtime = controls.get(31)
dsync = controls.get(32)
dfeedback = controls.get(37)
dsetsync = controls.get(36)

dsync:setSlot(25,1)

function setvisibility()
    pcoarse:setVisible(mode == 0)
    fcoarse:setVisible(mode == 1)
    rcoarse:setVisible(mode == 2)
    pwindow:setVisible(mode == 0)
    pfine:setVisible(mode == 0)
    mfine:setVisible(mode ~= 0)
    lfoamounthz:setVisible(mode ~= 0)
    lfoamountst:setVisible(mode == 0)
    envamounthz:setVisible(envison and (mode ~= 0))
    envamountst:setVisible(envison and (mode == 0))
    envattack:setVisible(envison)
    envrelease:setVisible(envison)
    dtime:setVisible(delayison and (delaysync == 0))
    dsync:setVisible(delayison and (delaysync ~= 0))
    dfeedback:setVisible(delayison)
    dsetsync:setVisible(delayison)    
    lfofreq:setVisible(lfosync == 0)
    lforate:setVisible(lfosync ~= 0)
    lfooffset:setVisible(lfosync ~= 0)
    lfosetspin:setVisible((lfosync == 0) and (wave < 8))
    lfophase:setVisible((wave == 8) or ((wave < 8) and ((lfosync ~= 0) or (spin == 0))))
    lfospin:setVisible((wave < 8 ) and (lfosync == 0) and (spin ~= 0))
    lfowidth:setVisible(wave == 9)
    lfoduty:setVisible(wave < 8)
end

function setwave(valueObject, value)
    wave = value
    setvisibility()
end

function setmode(valueObject, value)
    mode = value
    setvisibility()
end

function setdelaysync(valueObject, value)
    delaysync = value
    setvisibility()
end

function setspin(valueObject, value)
    spin = value
    setvisibility()
end

function setlfosync(valueObject, value)
    lfosync = value
    setvisibility()
end

function delayon(valueObject, value)
    delayison = (value ~= 0 )
    setvisibility()
end

function envon(valueObject, value)
    envison = (value ~= 0)
    setvisibility()
end

info.setText("by www.xot.nl")

function defaultFormatter(valueObject, value)
    return("")
end

function formatFloat (valueObject, value)
  return (string.format("%.2f",value/100))
end

function formatLargeFloat (valueObject, value)
  return (string.format("%.1f",value/10))
end

function formatdB (valueObject, value)
  return (string.format("%.1f dB",value/10))
end

function formatFreq (valueObject, value)
  return (string.format("%.1f Hz",value/10))
end

function formatPan (valueObject, value)
  if value < 0 then
    return (string.format("%iL", -value))
  elseif value == 0 then
    return "C"
  else
    return (string.format("%iR", value))
  end
end

function formatPercent (valueObject, value)
  return (string.format("%.1f %%",value/10))
end

function formatIntPercent (valueObject, value)
  return (string.format("%.0f %%",value/10))
end

function formatDegree (valueObject, value)
  return (string.format("%i *",value))
end

function formatSemitone (valueObject, value)
  return (string.format("%i st",value))
end

function formatFineSemitone (valueObject, value)
  return (string.format("%.2f st",value/100))
end

function formatDetune (valueObject, value)
  return (string.format("%i ct",value))
end

-- start/stop display drawing

function aa()
  window.stop()
end

function zz()
  window.resume()
end

-- handling patch requests to switch between mixer/effect 

function patch.onRequest (device)
  print ("Patch Request pressed");
  if device.id == 1
    then midi.sendSysex(PORT_1, {0x00, 0x21, 0x45, 0x7E, 0x7E})
  end
end

ltime = controls.get(10)
lbeat = controls.get(1)
lswing = controls.get(2)

lrtime = controls.get(21)
lrbeat = controls.get(12)
lrswing = controls.get(13)

rtime = controls.get(32)
rbeat = controls.get(23)
rswing = controls.get(24)

islsync = false
islrsync = false
isrsync = false

function setvisibility()
   ltime:setVisible(not islsync)
   lbeat:setVisible(islsync)
   lswing:setVisible(islsync)
   lrtime:setVisible(not islrsync)
   lrbeat:setVisible(islrsync)
   lrswing:setVisible(islrsync)
   rtime:setVisible(not isrsync)
   rbeat:setVisible(isrsync)
   rswing:setVisible(isrsync)
end

function lsync(valueObject, value)
    islsync = (value ~= 0)
    setvisibility()
end

function lrsync(valueObject, value)
    islrsync = (value ~= 0)
    setvisibility()
end

function rsync(valueObject, value)
    isrsync = (value ~= 0)
    setvisibility()
end

info.setText("by www.xot.nl")

function defaultFormatter(valueObject, value)
    return("")
end

function formatFloat (valueObject, value)
  return (string.format("%.2f",value/100))
end

function formatLargeFloat (valueObject, value)
  return (string.format("%.1f",value/10))
end

function formatdB (valueObject, value)
  return (string.format("%.1f dB",value/10))
end

function formatFreq (valueObject, value)
  return (string.format("%.1f Hz",value/10))
end

function formatPan (valueObject, value)
  if value < 0 then
    return (string.format("%iL", -value))
  elseif value == 0 then
    return "C"
  else
    return (string.format("%iR", value))
  end
end

function formatPercent (valueObject, value)
  return (string.format("%.1f %%",value/10))
end

function formatIntPercent (valueObject, value)
  return (string.format("%.0f %%",value/10))
end

function formatDegree (valueObject, value)
  return (string.format("%i *",value))
end

function formatSemitone (valueObject, value)
  return (string.format("%i st",value))
end

function formatFineSemitone (valueObject, value)
  return (string.format("%.2f st",value/100))
end

function formatDetune (valueObject, value)
  return (string.format("%i ct",value))
end

-- start/stop display drawing

function aaa()
  window.stop()
end

function zzz()
  window.resume()
end

-- handling patch requests to switch between mixer/effect 

function patch.onRequest (device)
  print ("Patch Request pressed");
  if device.id == 1
    then midi.sendSysex(PORT_1, {0x00, 0x21, 0x45, 0x7E, 0x7E})
  end
end

-- handling forwarding mixer updates to second E1 (if attached)

function forward(f)
  cmdt = {0x00, 0x21, 0x45, 0x08, 0x0D}
  cmds = f .. "()"
  for i=1, string.len(cmds) do
    cmdt[i+5]= string.byte(cmds,i,i)
  end
  midi.sendSysex(PORT_1,cmdt)
end

function forward2(f,p1,p2)
  cmdt = {0x00, 0x21, 0x45, 0x08, 0x0D}
  cmds = f .. "(" .. p1 .. "," .. p2 .. ")"
  for i=1, string.len(cmds) do
    cmdt[i+5]= string.byte(cmds,i,i)
  end
  midi.sendSysex(PORT_1,cmdt)
end

function aa()
  forward('aa')
end

function zz()
  forward('zz')
end

function utl(idx,label)
  forward2('utl', tostring(idx), '"'..label..'"')
end

function ursl(idx,label)
  forward2('ursl', tostring(idx), '"'..label..'"')
end

function seqv(idx,flag)
  if flag then
    forward2('seqv',tostring(idx),'true')
  else
    forward2('seqv',tostring(idx),'false')
  end
end

function smv(tc,rc)
  forward2('smv', tostring(tc), tostring(rc))
end

delaytime = controls.get(36)
fbtime = controls.get(34)
delayrate = controls.get(32)
fbrate = controls.get(33)

delayrate:setSlot(19,1)
fbrate:setSlot(31,1)

function sync(valueObject, value)
    delaytime:setVisible(value == 0)
    fbtime:setVisible(value == 0)
    delayrate:setVisible(value ~= 0)
    fbrate:setVisible(value ~= 0)
end

modulation = controls.get(31) 
damping = controls.get(8) 
diffusion = controls.get(11)

diffusion:setSlot(6,1)

dhbassx = controls.get(5)
dhbassmult = controls.get(6)
dhshape = controls.get(7)

dhbassx:setSlot(6,1)
dhbassmult:setSlot(12,1)
dhshape:setSlot(11,1)

function dhvis(flag)
    dhbassx:setVisible(flag)
    dhbassmult:setVisible(flag)    
    dhshape:setVisible(flag)
end

qzlow = controls.get(43)
qzdistance = controls.get(42)

qzlow:setSlot(11,1)
qzdistance:setSlot(12,1)

function qzvis(flag)
    qzlow:setVisible(flag)    
    qzdistance:setVisible(flag)
end

shpitch = controls.get(46)
shshimmer = controls.get(47)

shpitch:setSlot(11,1)
shshimmer:setSlot(12,1)

function shvis(flag)
    shpitch:setVisible(flag)    
    shshimmer:setVisible(flag)
end

tiwave = controls.get(52)
tiphase = controls.get(49)
titide = controls.get(51)
tirate = controls.get(50)

tiwave:setSlot(5,1)
tiphase:setSlot(6,1)
titide:setSlot(11,1)
tirate:setSlot(12,1)

function tivis(flag)
    tiwave:setVisible(flag)    
    tiphase:setVisible(flag)
    titide:setVisible(flag)    
    tirate:setVisible(flag)
end

prsixth = controls.get(40)
prseventh = controls.get(39)
prlow = controls.get(38)
prhi = controls.get(37)
prx = controls.get(41)

prsixth:setSlot(5,1)
prseventh:setSlot(6,1)
prlow:setSlot(10,1)
prhi:setSlot(11,1)
prx:setSlot(12,1)

function prvis(flag)
    prsixth:setVisible(flag)    
    prseventh:setVisible(flag)
    prlow:setVisible(flag)    
    prhi:setVisible(flag)
    prx:setVisible(flag)    
end

function algotype(valueObject, value)
    modulation:setVisible(value < 3)
    damping:setVisible(value < 4)
    diffusion:setVisible((value == 1) or (value == 2))
    dhvis(value == 0)
    qzvis(value == 1)
    shvis(value == 2)
    tivis(value == 3)
    prvis(value == 4)
end

